public interface UserRepository {
    User get(int id);
}
