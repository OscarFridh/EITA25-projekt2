public interface Logging {
    void log(String event);
}
